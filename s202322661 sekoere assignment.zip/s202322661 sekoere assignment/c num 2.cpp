#include<iostream>
using namespace std;

int main(){
	int numofcattles, limtforwealth = 20;
	cout<<"enter your number of cattles:";
	cin>>numofcattles;
	
	if(numofcattles<20){
		cout<<"unwealthy.";
		
	}
	else
		cout<<"wealthy";
	
		
	return 0;
	
}
