#include<iostream>/ 
using namespace std;

int main(){
	int number;
	
	cout<<"enter number number to show day: ";
	cin>>number;
	
	switch(number){
		case 1:
			cout<<"mantaha";
			break;
		
		case 2:
			cout<<"labobeli";
			break;
			
		case 3:
			cout<<"laborararo";
			break;
			
		case 4:
			cout<<"labone";
			break;
			
			
		case 5:
			cout<<"labohlano";
			break;
			
		case 6:
			cout<<"moqebelo";
			break;
			
		case 7:
			cout<<"sontaha";
			break;
			
		default:
			cout<<"error";
		
	}
	
	
	return 0;
}
